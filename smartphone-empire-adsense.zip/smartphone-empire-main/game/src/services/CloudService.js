// FILE: src/services/CloudService.js
// v2028.43 — [TRANSFER] Menambahkan getPlayerById & transferSilicon.
import { bus } from '../core/EventBus.js';

const SLOT_KEY = 'smartphone-empire:cloud-slot';

let _adapter = null;
let _status = 'disconnected';
let _userId = null;
let _email = null;
let _slot = _loadSlot();
let _authBound = false;

function _loadSlot() {
    try {
        const n = parseInt(localStorage.getItem(SLOT_KEY), 10);
        if (n >= 1 && n <= 9) return 1; 
    } catch (e) {}
    return 1;
}

function _setStatus(s) {
    if (_status === s) return;
    _status = s;
    bus.emit('cloud:status-changed', { status: _status });
}

function _setUser(u) {
    _userId = u && u.userId ? u.userId : null;
    _email = u && u.email ? u.email : null;
}

function _fail(err) {
    return { ok: false, reason: (err && err.message) || 'error', code: (err && err.code) || 'unknown' };
}

const NOT_CONFIGURED = { ok: false, reason: 'Cloud belum dikonfigurasi.', code: 'not_configured' };
const NOT_SIGNED_IN  = { ok: false, reason: 'Belum login.', code: 'not_signed_in' };

function _bindAuth() {
    if (_authBound || !_adapter || typeof _adapter.onAuthChange !== 'function') return;
    _authBound = true;
    _adapter.onAuthChange(function (event, user) {
        if (event === 'PASSWORD_RECOVERY') { bus.emit('cloud:password-recovery', {}); }
        if (user && user.userId) {
            const changed = user.userId !== _userId;
            _setUser(user);
            if (changed || _status !== 'connected') _setStatus('connected');
        } else if (event === 'SIGNED_OUT') {
            _setUser(null);
            _setStatus('disconnected');
        }
        bus.emit('cloud:auth-changed', { event: event, userId: _userId });
    });
}

export const CloudService = {
    isAvailable() { return !!_adapter; },
    getStatus() { return _status; },
    getUserId() { return _userId; },
    getEmail() { return _email; },

    getSlot() { return _slot; },
    setSlot(n) {
        n = parseInt(n, 10);
        if (!(n >= 1 && n <= 9)) return false;
        n = 1;                            
        _slot = n;
        try { localStorage.setItem(SLOT_KEY, String(n)); } catch (e) {}
        bus.emit('cloud:slot-changed', { slot: _slot });
        return true;
    },

    registerAdapter(adapter) {
        if (!adapter) return { ok: false, reason: 'Adapter kosong.' };
        if (_adapter === adapter) return { ok: true, already: true };
        _adapter = adapter;
        _authBound = false;
        _setStatus('disconnected');
        return { ok: true };
    },

    unregisterAdapter() {
        _adapter = null;
        _authBound = false;
        _setUser(null);
        _setStatus('disconnected');
    },

    async restoreSession() {
        if (!_adapter) return NOT_CONFIGURED;
        _setStatus('connecting');
        try {
            const u = await _adapter.init();
            _bindAuth();
            if (u && u.userId) {
                _setUser(u);
                _setStatus('connected');
                return { ok: true, userId: _userId, email: _email };
            }
            _setUser(null);
            _setStatus('disconnected');
            return { ok: false, reason: 'Tidak ada sesi.', code: 'no_session' };
        } catch (err) {
            _setStatus('disconnected');
            return _fail(err);
        }
    },

    async signIn(email, password) {
        if (!_adapter) return NOT_CONFIGURED;
        _setStatus('connecting');
        try {
            const res = await _adapter.signIn(email, password);
            _bindAuth();
            _setUser(res);
            _setStatus(_userId ? 'connected' : 'error');
            return { ok: !!_userId, userId: _userId, email: _email };
        } catch (err) {
            _setStatus('error');
            _setStatus('disconnected');
            return _fail(err);
        }
    },

    async signUp(email, password) {
        if (!_adapter) return NOT_CONFIGURED;
        if (typeof _adapter.signUp !== 'function') return { ok: false, reason: 'Pendaftaran tidak didukung.', code: 'unknown' };
        _setStatus('connecting');
        try {
            const res = await _adapter.signUp(email, password);
            _bindAuth();
            if (res.needsConfirm || !res.userId) {
                _setStatus('disconnected');
                return { ok: true, needsConfirm: true };
            }
            _setUser(res);
            _setStatus('connected');
            return { ok: true, needsConfirm: false, userId: _userId, email: _email };
        } catch (err) {
            _setStatus('disconnected');
            return _fail(err);
        }
    },

    async signOut() {
        if (!_adapter) return NOT_CONFIGURED;
        try {
            await _adapter.signOut();
            _setUser(null);
            _setStatus('disconnected');
            return { ok: true };
        } catch (err) {
            return _fail(err);
        }
    },

    async resetPassword(email) {
        if (!_adapter) return NOT_CONFIGURED;
        try { await _adapter.resetPassword(email); return { ok: true }; }
        catch (err) { return _fail(err); }
    },

    async updatePassword(password) {
        if (!_adapter) return NOT_CONFIGURED;
        try { await _adapter.updatePassword(password); return { ok: true }; }
        catch (err) { return _fail(err); }
    },

    async uploadSave(payload) {
        if (!_adapter) return NOT_CONFIGURED;
        if (!_userId) return NOT_SIGNED_IN;
        const p = Object.assign({}, payload);
        if (!p.slot) p.slot = _slot;
        bus.emit('cloud:sync-start', { direction: 'up' });
        try {
            const res = await _adapter.uploadSave(_userId, p);
            bus.emit('cloud:sync-success', { direction: 'up', at: Date.now(), slot: p.slot });
            return { ok: true, uploadedAt: res.uploadedAt, slot: p.slot };
        } catch (err) {
            bus.emit('cloud:sync-error', { direction: 'up', message: err.message, code: err.code });
            return _fail(err);
        }
    },

    async downloadSave(slot) {
        if (!_adapter) return NOT_CONFIGURED;
        if (!_userId) return NOT_SIGNED_IN;
        bus.emit('cloud:sync-start', { direction: 'down' });
        try {
            const payload = await _adapter.downloadSave(_userId, slot || _slot);
            bus.emit('cloud:sync-success', { direction: 'down', at: Date.now(), slot: slot || _slot });
            return { ok: true, payload: payload };
        } catch (err) {
            bus.emit('cloud:sync-error', { direction: 'down', message: err.message, code: err.code });
            return _fail(err);
        }
    },

    async listSaves() {
        if (!_adapter || !_userId) return [];
        try { return await _adapter.listSaves(_userId); }
        catch (err) { return []; }
    },

    async listSavesStrict() {
        if (!_adapter) return NOT_CONFIGURED;
        if (!_userId) return NOT_SIGNED_IN;
        try { return { ok: true, rows: await _adapter.listSaves(_userId) }; }
        catch (err) { return _fail(err); }
    },

    async subscribeSaves(cb) {
        if (!_adapter || !_userId || typeof _adapter.subscribeSaves !== 'function') return function () {};
        try { return await _adapter.subscribeSaves(_userId, cb); }
        catch (err) { return function () {}; }
    },

    async subscribeWallet(cb) {
        if (!_adapter || !_userId || typeof _adapter.subscribeWallet !== 'function') return function () {};
        try { return await _adapter.subscribeWallet(_userId, cb); }
        catch (err) { return function () {}; }
    },

    async subscribePresence(meta, onSync) {
        if (!_adapter || !_userId) return function () {};
        if (typeof _adapter.subscribePresence !== 'function') return function () {};
        try { return await _adapter.subscribePresence(_userId, meta, onSync); }
        catch (err) { return function () {}; }
    },

    async getProfile() {
        if (!_adapter || !_userId || typeof _adapter.getProfile !== 'function') return null;
        try { return await _adapter.getProfile(_userId); } catch (err) { return null; }
    },

    async updateProfile(fields) {
        if (!_adapter || !_userId) return NOT_SIGNED_IN;
        try { return { ok: true, profile: await _adapter.updateProfile(_userId, fields) }; }
        catch (err) { return _fail(err); }
    },

    async uploadPlayerAsset(name, fileOrBlob, contentType) {
        if (!_adapter || !_userId) return NOT_SIGNED_IN;
        try { return Object.assign({ ok: true }, await _adapter.uploadPlayerAsset(_userId, name, fileOrBlob, contentType)); }
        catch (err) { return _fail(err); }
    },

    async getPlayerAssetUrl(path, expiresSec) {
        if (!_adapter || !_userId) return NOT_SIGNED_IN;
        try { return { ok: true, url: await _adapter.getPlayerAssetUrl(path, expiresSec) }; }
        catch (err) { return _fail(err); }
    },

    async getGameAssetUrl(path) {
        if (!_adapter || typeof _adapter.getGameAssetUrl !== 'function') return NOT_CONFIGURED;
        try { return { ok: true, url: await _adapter.getGameAssetUrl(path) }; }
        catch (err) { return _fail(err); }
    },

    async listProfiles(orderBy) {
        if (!_adapter) return NOT_CONFIGURED;
        if (!_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.listProfiles !== 'function') return NOT_CONFIGURED;
        try { return { ok: true, rows: await _adapter.listProfiles(orderBy) }; }
        catch (err) { return _fail(err); }
    },

    async syncPlayerProfile(fields) {
        if (!_adapter) return NOT_CONFIGURED;
        if (!_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.rpcSyncProfile !== 'function') return NOT_CONFIGURED;
        try { await _adapter.rpcSyncProfile(fields); return { ok: true }; }
        catch (err) { return _fail(err); }
    },

    async syncCompanyLevel(fields) {
        if (!_adapter) return NOT_CONFIGURED;
        if (!_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.rpcSyncCompanyLevel !== 'function') return NOT_CONFIGURED;
        try { return { ok: true, data: await _adapter.rpcSyncCompanyLevel(fields) }; }
        catch (err) { return _fail(err); }
    },

    async getPlayerAssetUrls(paths, expiresSec) {
        if (!_adapter || !_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.getPlayerAssetUrls !== 'function') return NOT_CONFIGURED;
        try { return { ok: true, items: await _adapter.getPlayerAssetUrls(paths, expiresSec) }; }
        catch (err) { return _fail(err); }
    },

    async getProfileById(id) {
        if (!_adapter) return NOT_CONFIGURED;
        if (!_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.getProfileById !== 'function') return NOT_CONFIGURED;
        try { return { ok: true, profile: await _adapter.getProfileById(id) }; }
        catch (err) { return _fail(err); }
    },

    async getSiliconBalance() {
        if (!_adapter) return NOT_CONFIGURED;
        if (!_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.rpcGetSilicon !== 'function') return NOT_CONFIGURED;
        try { return { ok: true, balance: await _adapter.rpcGetSilicon() }; }
        catch (err) { return _fail(err); }
    },

    async getPublicId() {
        if (!_adapter) return NOT_CONFIGURED;
        if (!_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.rpcGetMyPublicId !== 'function') return NOT_CONFIGURED;
        try { return { ok: true, publicId: await _adapter.rpcGetMyPublicId() }; }
        catch (err) { return _fail(err); }
    },

    // [NEW] Cek info pemain sebelum transfer
    async getPlayerById(publicId) {
        if (!_adapter) return NOT_CONFIGURED;
        if (!_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.rpcGetPlayerById !== 'function') return NOT_CONFIGURED;
        try { return { ok: true, data: await _adapter.rpcGetPlayerById(publicId) }; }
        catch (err) { return _fail(err); }
    },

    // [NEW] Eksekusi transfer SIL
    async transferSilicon(receiverId, amount) {
        if (!_adapter) return NOT_CONFIGURED;
        if (!_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.rpcTransferSilicon !== 'function') return NOT_CONFIGURED;
        try { return { ok: true, data: await _adapter.rpcTransferSilicon(receiverId, amount) }; }
        catch (err) { return _fail(err); }
    },

    async addSiliconServer() { return { ok: false, code: 'FORBIDDEN' }; },

    async claimDailySilicon() {
        if (!_adapter) return NOT_CONFIGURED;
        if (!_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.rpcClaimDaily !== 'function') return NOT_CONFIGURED;
        try { return { ok: true, balance: await _adapter.rpcClaimDaily() }; }
        catch (err) { return _fail(err); }
    },

    async spendSiliconServer(amount, requestId, reason) {
        if (!_adapter) return NOT_CONFIGURED;
        if (!_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.rpcSpendSilicon !== 'function') return NOT_CONFIGURED;
        try { return { ok: true, balance: await _adapter.rpcSpendSilicon(amount, requestId, reason) }; }
        catch (err) { return _fail(err); }
    },

    async exchangeSiliconServer(pkg, year, requestId) {
        if (!_adapter) return NOT_CONFIGURED;
        if (!_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.rpcExchangeSilicon !== 'function') return NOT_CONFIGURED;
        try { return { ok: true, data: await _adapter.rpcExchangeSilicon(pkg, year, requestId) }; }
        catch (err) { return _fail(err); }
    },

    async refundSiliconServer(requestId) {
        if (!_adapter) return NOT_CONFIGURED;
        if (!_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.rpcRefundSilicon !== 'function') return NOT_CONFIGURED;
        try { return { ok: true, balance: await _adapter.rpcRefundSilicon(requestId) }; }
        catch (err) { return _fail(err); }
    },

    async claimQuestSilicon(questId) {
        if (!_adapter) return NOT_CONFIGURED;
        if (!_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.rpcClaimQuest !== 'function') return NOT_CONFIGURED;
        try { return { ok: true, balance: await _adapter.rpcClaimQuest(questId) }; }
        catch (err) { return _fail(err); }
    },

    async createPaymentOrder(orderId, packageId, priceIdr, silAmount) {
        if (!_adapter) return NOT_CONFIGURED;
        if (!_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.rpcCreatePaymentOrder !== 'function') return NOT_CONFIGURED;
        try {
            return await _adapter.rpcCreatePaymentOrder(orderId, packageId, priceIdr, silAmount);
        } catch (err) {
            return _fail(err);
        }
    },

    async checkPaymentStatus(orderId) {
        if (!_adapter) return NOT_CONFIGURED;
        if (!_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.rpcCheckPaymentStatus !== 'function') return NOT_CONFIGURED;
        try {
            var status = await _adapter.rpcCheckPaymentStatus(orderId);
            return { ok: true, data: status };
        } catch (err) {
            return _fail(err);
        }
    },

    async getPendingPayments() {
        if (!_adapter || !_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.rpcGetPendingPayments !== 'function') return NOT_CONFIGURED;
        try { return { ok: true, data: await _adapter.rpcGetPendingPayments() }; }
        catch (err) { return _fail(err); }
    },

    async adminApprovePayment(orderId) {
        if (!_adapter || !_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.rpcAdminApprove !== 'function') return NOT_CONFIGURED;
        try { return { ok: true, data: await _adapter.rpcAdminApprove(orderId) }; }
        catch (err) { return _fail(err); }
    },

    async adminGetAllProfiles() {
        if (!_adapter || !_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.rpcAdminGetProfiles !== 'function') return NOT_CONFIGURED;
        try { return { ok: true, data: await _adapter.rpcAdminGetProfiles() }; }
        catch (err) { return _fail(err); }
    },

    async adminSetSilicon(userId, amount) {
        if (!_adapter || !_userId) return NOT_SIGNED_IN;
        if (typeof _adapter.rpcAdminSetSilicon !== 'function') return NOT_CONFIGURED;
        try { return { ok: true, data: await _adapter.rpcAdminSetSilicon(userId, amount) }; }
        catch (err) { return _fail(err); }
    },
};
